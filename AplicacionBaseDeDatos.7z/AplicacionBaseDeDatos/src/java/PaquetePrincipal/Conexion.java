package PaquetePrincipal;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.*;
/**
 *
 * @author lauro
 */
public class Conexion {
 private Connection conexión = null;
    private Statement sentenciaSQL = null;

    public void Conectar() {
        try {
            String controlador = "com.mysql.jdbc.Driver";
            Class.forName(controlador).newInstance();
            conexión = DriverManager.getConnection("jdbc:mysql://localhost:3306/trabajofinal", "root", "root");///////////////777
            sentenciaSQL = getConnectión().createStatement();

        } catch (ClassNotFoundException e) {
            System.out.println("no se pudo cargar el controlador " + " " + e);
        } catch (SQLException e) {
            System.out.println("Exepcion SQL: " + e.getMessage());
        } catch (InstantiationException e) {
            System.out.println("OBJETO NO CERRRADO: " + e.getMessage());
        } catch (IllegalAccessException e) {
            System.out.println("Acceso ilegal: " + e.getMessage());
        }
    }

    public void cerrar() {
        try {
            if(getSentenciaSQL() != null){
                getSentenciaSQL().close();
            }
            if (getConnectión() != null) {
                getConnectión().close();
            }

        } catch (SQLException ignorada) {
        }
    }

    public Connection getConnectión() {
        return conexión;
    }

    public Statement getSentenciaSQL(){
        return sentenciaSQL;
    }

    com.mysql.jdbc.Statement createStatement() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
