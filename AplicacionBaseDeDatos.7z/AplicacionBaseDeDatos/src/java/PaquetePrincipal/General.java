/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PaquetePrincipal;

import com.mysql.jdbc.Statement;
import java.awt.font.NumericShaper;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
/**
 *
 * @author lauro
 */
public class General extends HttpServlet {

    ResultSet cdr = null;
    ResultSet cdr1 = null;
    Statement sentenciaSQL = null;
    Conexion conecta = new Conexion();

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        conecta.Conectar();
        sentenciaSQL = (Statement) conecta.getSentenciaSQL();

    }
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet General</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet General at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
        } finally { 
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String cual = request.getParameter("marr");

         if (cual.equals("tabla")) {
            out.println("Crear tablas<br><br>"
               + "Nombre de la tabla: <input type='text' id='nombretabla'><br> <br>");
              out.println(" <button id='enviartabla' onclick='listo();' >Listo</button>");
        }else if (cual.equals("Personas")) {
            String dato = request.getParameter("nombretabla");
            out.println("<input type='hidden' id='tablaescondida' value='"+dato+"'>");
            out.println("<div align='center'>Campos de la tabla</div>");
            out.println("<table  width='100%'>"
                    + "<tr> <td>");
            out.println(" <div align='left' >selecciona: <select id='todos' onchange='hola();'>"
                    + " <option value='Nombre'>Nombre</option>"
                     + " <option value='Apellido'>Apellido</option>"
                    + " <option value='Direccion'>Direccion</option>"
                    + " <option value='Ciudad'>Ciudad</option>"
                    + " <option value='Estado'>Estado</option>"
                     + " <option value='Correo'>Correo</option>"
                    + " <option value='Usuario'>Usuario</option>"
                    + " <option value='Password'>Password</option>"
                     + " <option value='Signo'>Signo zodiacal</option>"
                    + " <option value='ocupacion  '>ocupación  </option>"
                    + " <option value='Dominio'>Dominio </option>"
                    + " <option value='Estatura'>Estatura </option>"
                    + " <option value='Peso'>Peso</option>"
                    + "</select> ");

              out.println(" <button id='enviartabla' onclick='agrega();' >Agregar</button> </div>");
              out.println("</td><td><div align='right'> <textarea name='area'id='area' readonly='readonly' rows='10' cols='40'>Campos de la tabla:</textarea>");
              out.println("<br> <button id='enviartabla' onclick='creatabla();' >Crear</button>  </div> </td></tr></table> ");

        }else if(cual.equals("claro")) {
            String tabla = request.getParameter("nombretabla");
            String text = request.getParameter("texto");

            String words[] = text.split("\n");
           int numero=0;
            for(String dia : words){
                 numero=numero+1;
            }

            String uno="Create table "+tabla+"(";
            String dos="";
            String sentelect="";
            for (int i=1; i < numero; i++) {
              
            }
            for (int i=1; i < numero-1; i++) {
              sentelect= sentelect+" "+words[i]+" "+",";
              dos=dos+" "+words[i]+" varchar(80) not null ,";
            }
            sentelect= sentelect+" "+words[numero-1];
            String creatablasen=uno+dos+words[numero-1]+" varchar(80) not null );";
            String sentenciacreadocu="SELECT "+sentelect+" "+"FROM prueba2 INTO OUTFILE 'C:/Users/lauro/Documents/archovo/"+tabla+".csv'";
            String cargar="LOAD DATA INFILE 'C:/Users/lauro/Documents/archovo/"+tabla+".csv' INTO TABLE "+tabla;
           out.println("Listo archivo creado!");
           //out.println(cargar);
             try {
                sentenciaSQL.executeUpdate(creatablasen);
            } catch (SQLException ex) {
                   out.println("Excepción SQL: "+ex.getMessage());
            }
         
          try {
                sentenciaSQL.executeQuery(sentenciacreadocu+ "FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\r\n';");

            } catch (SQLException ex) {
                   out.println("Excepción SQL: "+ex.getMessage());
            }
              try {
                sentenciaSQL.execute(cargar+" "+ "FIELDS TERMINATED BY ';' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\r\n';");
            } catch (SQLException ex) {
                   out.println("Excepción SQL: "+ex.getMessage());
            }
             


        }

    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
