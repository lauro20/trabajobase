/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

var xhr;
xhr=new XMLHttpRequest();

function diseñotabla(){
    var usu="tabla";
    
    xhr.open("POST","General",true);
    xhr.onreadystatechange=dos;
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("marr="+usu);
}
function dos(){
    if(xhr.readyState==4){
        document.getElementById("inicio").innerHTML=xhr.responseText;
    }
}
function listo(){
    var tit="Personas";
    var a=document.getElementById("nombretabla").value;
    xhr.open("POST","General",true);
    xhr.onreadystatechange=dos;
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("marr="+tit+"&nombretabla="+a);
}
function agrega(){
    var titulos=document.getElementById("area").value;
    var ti ="claro"
    var titulo=document.getElementById("todos");
    var tit=titulo.options[titulo.selectedIndex].value;
    document.getElementById("area").value=titulos+'\n'+tit;
 
}
function creatabla(){
    var tit="claro";
    var nombretabla=document.getElementById("tablaescondida").value;
    var text = document.getElementById("area").value;
    xhr.open("POST","General",true);
    xhr.onreadystatechange=dos;
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("marr="+tit+"&nombretabla="+nombretabla+"&texto="+text);


    

}

